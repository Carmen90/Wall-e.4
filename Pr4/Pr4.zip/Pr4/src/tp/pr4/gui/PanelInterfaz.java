package tp.pr4.gui;

import java.util.EventListener;
import java.util.Observer;

public interface PanelInterfaz extends Observer{
	public void fijarControlador(EventListener controlador);
}
