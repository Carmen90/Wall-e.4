package tp.pr4.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import tp.pr4.Direction;
import tp.pr4.NavigationModule;

/**
 * @author Carmen Acosta Morales y Nerea Ramirez Lamela
 * 
 * Esta clase se encarga de mostrar a walle y la informacion sobre la ciudad
 * Tiene una matriz de PlaceCell de 11x11 cuyo primer lugar enpieza en la posicion (5,5)
 * Tambi�n tiene un area que muestra las descrici�n del lugar y una etiqueta con el icono de walle
 *
 */
@SuppressWarnings("serial")
public class NavigationPanel extends JPanel implements Observer{
	private JLabel walle;
	private JTextArea texto;
	private PlaceCell [][] places ;
	private JPanel placesPanel;
	private JPanel scrollPanel;
	private JScrollPane scroll;
	
	public NavigationPanel(){
		this.places = new PlaceCell[11][11];
		for ( int i = 0; i < 11; i++){
			for ( int j = 0; j < 11; j++){
				this.places[i][j] = new PlaceCell();
			}
		}
		initNavigPanel();
	}
	
	public void panelPlaces (){
		this.placesPanel = new JPanel();
        LayoutManager thisLayout = new GridLayout(11,11);
        this.placesPanel.setLayout(thisLayout);
        this.setPreferredSize(new java.awt.Dimension (500, 300));
        this.placesPanel.setBorder( new TitledBorder ("City Map"));
		for ( int i = 0; i < 11; i++){
			for ( int j = 0; j < 11; j++){
				this.placesPanel.add (places[i][j]);
			}
		}
		
	}
	
	/**
	 * M�todo que se encraga de crear el panel en el que se encuentra el Log
	 * El log muestra las descripciones de los lugares por los que pasa walle
	 * 
	 */
	public void panelScroll(){
		//Inicializaciones de los atributos usados en eset panel
		this.scrollPanel = new JPanel ();
		this.scroll = new JScrollPane();
    	this.scrollPanel = new JPanel();
    	
    	
    	this.scrollPanel.setBorder(new TitledBorder("Log"));
     //   JScrollBar vertical = new JScrollBar( JScrollBar.VERTICAL );
        this.scrollPanel.setName("Navigation");
        
		texto = new JTextArea(5, 30);
		//texto.add(vertical);
		this.texto.setEditable(false);
		this.texto.setName("texto");
		scroll = new JScrollPane(texto);
		
		this.add(scroll, BorderLayout.CENTER);
		this.scrollPanel.add(this.scroll);
		this.scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		this.scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		
        LayoutManager thisLayout = new GridLayout();
        this.scrollPanel.setLayout(thisLayout);
		
	}
	
	public void initNavigPanel(){
		this.walle = new JLabel( new ImageIcon ("walleNorth.png"));
		this.walle.setName( "walle");
		
		this.panelPlaces();
		this.add(this.walle);
		this.add(this.placesPanel);
		panelScroll();
		
		this.setLayout(new BoxLayout(this, 2));
	}



	public JPanel getScrollPanel() {
		return scrollPanel;
	}

	public JLabel getWalle() {
		return walle;
	}
	
	/**
	 * M�todo que se encarga de actualizar todo el panel. Obteniendo del modelo los datos.
	 * @param arg0 contiene el modelo
	 * @param arg1 contiene el argumento pasado desde el modelo.
	 */
	public void update(Observable arg0, Object arg1){
		NavigationModule modelo = (NavigationModule) arg0;	
		
		this.actualizaLog(modelo.getCurrentPlace().toString());
		this.actualizaWalle(modelo.getDirection());
	}
	
	public void actualizaWalle ( Direction direction){
		if (direction == Direction.NORTH){
			this.walle = new JLabel( new ImageIcon ("walleNorth.png"));
		//	this.walle.setIcon(new ImageIcon ("walleNorth.png"));
		}else if (direction == Direction.SOUTH){
			this.walle = new JLabel( new ImageIcon ("walleSouth.png"));
		//	this.walle.setIcon(new ImageIcon ("walleSouth.png"));
		}else if (direction == Direction.EAST){
			//((JLabel) this.getComponent(0)).setIcon (new ImageIcon ("walleEast.png"));
			//this.walle.setIcon(new ImageIcon ("walleEast.png"));
			this.walle = new JLabel( new ImageIcon ("walleEast.png"));
		}else if (direction == Direction.WEST){
			this.walle = new JLabel( new ImageIcon ("walleWest.png"));
			//this.walle.setIcon(new ImageIcon ("walleWest.png"));
		}
		this.walle.setName("walle");
	}
	
	public void actualizaLog ( String lugar){
		this.texto.setText(lugar);
	}

}
