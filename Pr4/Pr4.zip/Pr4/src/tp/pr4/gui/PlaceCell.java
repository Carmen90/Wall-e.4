package tp.pr4.gui;

import javax.swing.JButton;



/**
 * @author Carmen Acosta Morales y Nerea Ramirez Lamela
 * 
 * Representa un lugar en la ciudad. Es un button cuyo nombre es el nombre del lugar.
 * No modifica un lugar. 
 * Cuando el usuario pincha en un PlaceCell el Panel mostrara una descripcion del lugar que ha sido visitado previamente
 *
 */
@SuppressWarnings("serial")
public class PlaceCell extends JButton{
//	private JButton buttonPlace;
	public PlaceCell (){
		//initPlaceCell();
	}
	
	
	public void initPlaceCell(){
		/*this.buttonPlace = new JButton ();
		
		this.buttonPlace.setText("");
		this.buttonPlace.setName("buttonPlace");
		
		this.add(this.buttonPlace);*/
	}

}
