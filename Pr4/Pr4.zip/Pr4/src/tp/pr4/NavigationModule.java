package tp.pr4;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventObject;
import java.util.Observable;

import javax.swing.JComboBox;

import tp.pr4.gui.NavigationPanel;
import tp.pr4.instructions.exceptions.InstructionExecutionException;
import tp.pr4.items.Item;

/**
 * This class is in charge of the robot navigation features.
 * It contains the city where the robot looks for garbage,
 * the current place where the robot is, and the current direction of the robot.
 * It contains methods to handle the different robot movements and
 * to pick and drop items at the current place.
 */
public class NavigationModule extends Observable implements ActionListener{
	private City city;
	private Direction direction;
	private Place initialPlace;
	private String turn;
	private NavigationPanel navigPanel;
	
	public NavigationModule (){
	}
	/**
	 * Navigation module constructor.
	 *  It needs the city map and the initial place
	 * @param aCity
	 * @param initialPlace
	 */
	public NavigationModule ( City aCity, Place initialPlace){
		this.city = aCity;
		this.initialPlace = initialPlace;
		this.direction = Direction.NORTH;
		this.navigPanel = new NavigationPanel ();
		this.turn = "RIGHT";
	}
	/**
	 * Checks if the robot has arrived at a spaceship
	 * @return: true if an only if the current place is the spaceship
	 */
	public boolean atSpaceship (){
		boolean isSpace=false;
		if ( this.initialPlace.isSpaceship()){
			isSpace= true;
		}
		return isSpace;
	}
	/**
	 * Drop an item in the current place.
	 * It assumes that there is no other item with the same name/id there.
	 * Otherwise, the behaviour is undefined.
	 * @param it
	 */
	public void dropItemAtCurrentPlace(Item it){
		if ( !this.initialPlace.existItem(it.getId())){
			this.initialPlace.addItem(it);
		}
	}
	/**
	 * Checks if there is an item with a given id in this place
	 * @param id: true if and only if an item with this id is in the current place
	 * @return
	 */
	public boolean findItemAtCurrentPlace(String id){
		return this.initialPlace.existItem(id);
	}
	/**
	 * Returns the robot heading
	 * @return The direction where the robot is facing to.
	 */
	public Direction getCurrentHeading(){
		return this.direction;
	}
	/**
	 * Returns the current place where the robot is (for testing purposes)
	 * @return: The current place
	 */
	public Place getCurrentPlace(){
		return this.initialPlace;
	}
	/**
	 * Returns the street opposite the robot
	 * @return
	 */
	public Street getHeadingStreet(){
		return this.city.lookForStreet( this.initialPlace, this.direction);
	}
	/**
	 * Initializes the current heading according to the parameter
	 * @param heading
	 */
	public void initHeading (Direction heading){
		this.direction = heading;
	}
	/**
	 * The method tries to move the robot following the current direction.
	 * If the movement is not possible because there is no street,
	 * or there is a street which is closed, then it throws an exception.
	 * Otherwise the current place is updated according to the movement
	 * @throws InstructionExecutionException
	 */
	public void move () 
			throws InstructionExecutionException{
				
		Street calle = this.getHeadingStreet();
		
		if(calle==null){
			throw new InstructionExecutionException();
		}
		else{
			if(calle.isOpen()){
				this.initialPlace = calle.nextPlace(this.initialPlace);
				this.setChanged();
				this.notifyObservers();
				this.navigPanel.actualizaLog(this.initialPlace.toString());
			}
			else{
				throw new InstructionExecutionException();
			}			
		}
		
	}
/**
 * Tries to pick an item characterized by a given identifier from the current place.
 *  If the action was completed the item is removed from the current place.
 * @param id
 * @return: The item of identifier id if it exists in the place. Otherwise the method returns null
 */
	public Item pickItemFromCurrentPlace(java.lang.String id){
		Item item = null;
		if( this.initialPlace.existItem(id)){
			item = this.initialPlace.pickItem(id);
		}
		return item;
	}
	/**
	 * Updates the current direction of the robot according to the rotation
	 * @param rotation
	 */
	public void rotate (Rotation rotation){
		if ( rotation == Rotation.LEFT) {
			if ( this.direction == Direction.EAST){
				this.direction = Direction.NORTH;
				informarDireccion ();
			}
			else if ( this.direction == Direction.NORTH ){
				this.direction = Direction.WEST;
				informarDireccion ();
			}
			else if ( this.direction == Direction.WEST){
				this.direction = Direction.SOUTH;
				informarDireccion ();
			}
			else if ( this.direction == Direction.SOUTH){
				this.direction = Direction.EAST;
				informarDireccion ();
			}
		}else if (rotation == Rotation.RIGHT){
			if ( this.direction == Direction.EAST){
				this.direction = Direction.SOUTH;
				informarDireccion ();
			}
			else if ( this.direction == Direction.NORTH ){
				this.direction = Direction.EAST;
				informarDireccion ();
			}
			else if ( this.direction == Direction.WEST){
				this.direction = Direction.NORTH;
				informarDireccion ();
			}
			else if ( this.direction == Direction.SOUTH){
				this.direction = Direction.WEST;
				informarDireccion ();
				}
			}
			else {
				System.out.println( "WALL·E > WALL·E says: I do not understand. Please repeat" );
				
			}
			
	}
	
	public void informarDireccion (){
		this.setChanged();
		this.notifyObservers();
		this.navigPanel.actualizaWalle(this.direction);
	}
	/**
	 * Prints the information (description + inventory) of the current place
	 */
	public void scanCurrentPlace(){
		this.initialPlace.toString();
	}

	public Place getInitialPlace() {
		return initialPlace;
	}
	public Direction getDirection() {
		return direction;
	}
    
	/** 
	 * <p> M�todo que se encarga dependiendo del evento de modificar o no el modelo.
	 * 
	 * <p> La vista se actualiar� a partir de los observadores.
	 * 
	 * @param fuente el que ha realizado la solicitud de modificaci�n del modelo.
	 */
	private void cambiarModelo (Component fuente) {
	
		if ( fuente.getName().equals("jButtonTurn")){
			if ( this.turn.equalsIgnoreCase("left")){
				this.rotate(Rotation.LEFT);
				
			}
			else {
				this.rotate(Rotation.RIGHT);
			}	
		}
		else if (fuente.getName().equals("comboTurn")){
			@SuppressWarnings("rawtypes")
			JComboBox gira = (JComboBox) fuente;
			this.turn =  (String)gira.getSelectedItem();
		}
    }
	

	/**
	 * M�todo para tratar los eventos de forma gen�rica. 
	 * Se encarga tanto de solicitar la modificaci�n al modelo como de informar a la vista
	 * @param e el evento a tratar
	 */
	private void trataEventoGenerico(EventObject event){
		Component fuente = (Component) event.getSource(); // el que gener� el evento
		System.err.println(fuente.getName());
		cambiarModelo(fuente);
	}
	        
	
	/**
	 * Se tratan los eventos del tipo <code>ActionEvent</code> informando cuando es necesario a la vista y al modelo.
	 */
	@Override
	public void actionPerformed(ActionEvent ae) {
		System.err.print("NAVIGATION: ");
	    trataEventoGenerico(ae);
	}
}
